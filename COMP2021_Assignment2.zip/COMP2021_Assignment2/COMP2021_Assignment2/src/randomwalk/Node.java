package randomwalk;

import java.util.HashSet;

class Node{

    // degree of a node is the number of adjacency nodes, i.e., the number of nodes that are connected to this node by an edge.
    private int degree;
    //The graph this node belongs to
    private randomwalk.Graph graph;

    public Graph getGraph(){
        return this.graph;
    }

    public void setGraph(Graph graph){
        this.graph = graph;
    }

    public void setDegree(){
        // Task 3.1: Calculate this.degree based on the random walk sequences.
        HashSet<Node> res = new HashSet<>();
        for (RandomWalkSequence path: graph.getAllRandomWalkSequences()){
            int index1 = path.getSequence().indexOf(this);
            for (Node node1 : path.getSequence()){
                int index2 = path.getSequence().indexOf(node1);
                if (Math.abs(index2-index1)<=1){
                    res.add(node1);
                }
            }
        }
        this.degree = res.size();
    }


    public int getDegree(){
        return this.degree;
    }
    public boolean appearInPath(Node o,RandomWalkSequence path){
            for (Node node1: path.getSequence()){
                if (node1.equals(o)) return true;
            }

        return false;
    }
    public double transitionProbability(Node o){
        if(o == null){
            throw new IllegalArgumentException();
        }

        // Task 3.2: Given another node o, obtain the transition probability from this node to the given node.
        // transition probability is calculated by f(this, o) / f(this, all).
        // f(this, o) is the frequency of o as the next node of this within all random walk sequences.
        // f(this, all) is the frequency of this having a next node within all random walk sequences.
        // When f(this, all) = 0, the transition probability is 0.
        double res;
        int count1 = 0,count2 = 0;
        for (RandomWalkSequence path: getGraph().getAllRandomWalkSequences()){
            if (appearInPath(this,path)) {
                count2++;
                for (Node node1: path.getSequence()){
                    if (node1.equals(o) && path.getSequence().indexOf(node1)-path.getSequence().indexOf(this)==1){
                        count1++;
                    }
            }
            }
        }
        res = (double)count1/count2;
        return res;
    }
}