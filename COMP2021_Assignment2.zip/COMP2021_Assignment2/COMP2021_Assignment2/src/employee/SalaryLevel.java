package employee;

/**
 * Levels of salary.
 */
public enum SalaryLevel {
    ENTRY(1), JUNIOR(1.25), SENIOR(1.5), EXECUTIVE(2);

    // Task 1.5: Add missing code here.
    private final double number;
    SalaryLevel(double num){
        this.number = num;
    }
    double getScale(){
        return number;
    }

}