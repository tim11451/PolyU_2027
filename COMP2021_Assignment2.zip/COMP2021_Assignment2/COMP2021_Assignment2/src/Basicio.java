import java.nio.file.Path;

public class Basicio {
    public static void main(String[] args) {
        Path p1 = "";
    }

}
