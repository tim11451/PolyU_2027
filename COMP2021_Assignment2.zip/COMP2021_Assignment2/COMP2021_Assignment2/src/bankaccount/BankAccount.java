package bankaccount;

/** A bank account object. */
public class BankAccount { 

    private int balance;

	/** Instantiate an account with 'initialBalance'. */
    public BankAccount(int initialBalance){
        if(initialBalance < 0)
            throw new IllegalArgumentException();

        balance = initialBalance;
    }

	/** Balance of the account. The balance should never be negative. */
    public int getBalance(){
        return balance;
    }

	/** Deposit 'amount' into this account. 'amount' should always be positive. */
    public void deposit(int amount){
        if(amount <= 0)
            throw new IllegalArgumentException();
        // Task 4.1: Add missing code here.
        synchronized (this){
            this.balance += amount;
            notifyAll();
        }

    }

	/** Withdraw 'amount' from this account. 'amount' should always be positive. */
    public void withdraw(int amount){
        if(amount <= 0)
            throw new IllegalArgumentException();
        // Task 4.2: Add missing code here.
        while(amount > balance){
            try{
                synchronized (this){
                    wait();
                }
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }balance -= amount;

    }
}
